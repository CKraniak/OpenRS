#include "gameevent.h"

//template <class T> GameEvent<T>::GameEvent()
//{

//}

