#ifndef BEHAVIOR_ALISASES_H
#define BEHAVIOR_ALISASES_H

#include "dispatcher.h"

extern struct CommandDescriptor BDESC_ANY;
extern struct CommandDescriptor BDESC_BUMP;

#endif // BEHAVIOR_ALISASES_H
