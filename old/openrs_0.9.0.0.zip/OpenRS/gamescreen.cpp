/** Manages any multiple panes.
  * Will be the top display widget.
  */

#include "gamescreen.h"

GameScreen::GameScreen()
{
}
