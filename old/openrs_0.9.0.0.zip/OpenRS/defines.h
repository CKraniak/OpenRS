#ifndef DEFINES_H
#define DEFINES_H

// Only developing the ASCII console version now.
#define ORS_ASCII_CONSOLE 1
//#define ORS_WIN32 1
//#define ORS_MAC 1
//#define ORS_LINUX_UBUNTU 1

#endif // DEFINES_H
