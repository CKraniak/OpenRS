#ifndef GAMEOPTIONSET_H
#define GAMEOPTIONSET_H

class GameOptionSet
{
public:
    GameOptionSet();
};

#endif // GAMEOPTIONSET_H
