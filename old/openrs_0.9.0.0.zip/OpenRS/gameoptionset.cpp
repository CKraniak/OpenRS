/** Mostly just a container for all of the game options.
  */

#include "gameoptionset.h"

GameOptionSet::GameOptionSet()
{
}
