/** Passes district map information throught the world object
  * to the world map display screen.
  */

#include "districtmapinfo.h"

DistrictMapInfo::DistrictMapInfo()
{
}
