#ifndef GAMESCREEN_H
#define GAMESCREEN_H

class GameScreen
{
public:
    GameScreen();
};

#endif // GAMESCREEN_H
