#ifndef DISTRICTMAPINFO_H
#define DISTRICTMAPINFO_H

class DistrictMapInfo
{
public:
    DistrictMapInfo();
};

#endif // DISTRICTMAPINFO_H
