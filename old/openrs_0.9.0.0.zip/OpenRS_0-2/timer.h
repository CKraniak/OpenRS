#ifndef TIMER_H
#define TIMER_H

class Timer
{
public:
    Timer();
};

#endif // TIMER_H
