#ifndef CORE_H
#define CORE_H

class Core
{
public:
    Core();
};

#endif // CORE_H
