#ifndef CONFIGURATIONMANAGER_H
#define CONFIGURATIONMANAGER_H

class ConfigurationManager
{
public:
    ConfigurationManager();
};

#endif // CONFIGURATIONMANAGER_H
