#include "behavior.h"

Behavior::Behavior()
{
}
