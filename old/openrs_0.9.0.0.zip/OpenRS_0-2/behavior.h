#ifndef BEHAVIOR_H
#define BEHAVIOR_H

class Behavior
{
public:
    Behavior();
};

#endif // BEHAVIOR_H
