#include "timer.h"

Timer::Timer()
{
}
