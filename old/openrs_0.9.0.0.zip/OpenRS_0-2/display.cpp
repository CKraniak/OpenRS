#include "display.h"

Display::Display()
{
}
