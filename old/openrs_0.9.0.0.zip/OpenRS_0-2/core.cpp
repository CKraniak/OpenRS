#include "core.h"

Core::Core()
{
}
