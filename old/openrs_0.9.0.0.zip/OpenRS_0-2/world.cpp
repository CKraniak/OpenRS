#include "world.h"

World::World()
{
}
