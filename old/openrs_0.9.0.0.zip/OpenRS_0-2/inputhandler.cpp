#include "inputhandler.h"

InputHandler::InputHandler()
{
}

InputHandler::InputHandler(InputType, Observer &)
{
}
