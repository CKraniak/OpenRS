#ifndef DISPLAY_H
#define DISPLAY_H

class Display
{
public:
    Display();
};

#endif // DISPLAY_H
