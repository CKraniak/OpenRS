#ifndef TERRAIN_H
#define TERRAIN_H

class Terrain
{
public:
    Terrain();
};

#endif // TERRAIN_H
