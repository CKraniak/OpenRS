#ifndef WORLD_H
#define WORLD_H

class World
{
public:
    World();
};

#endif // WORLD_H
