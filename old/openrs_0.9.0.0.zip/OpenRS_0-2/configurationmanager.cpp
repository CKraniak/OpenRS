#include "configurationmanager.h"

ConfigurationManager::ConfigurationManager()
{
}
