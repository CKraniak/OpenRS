#ifndef ITEM_H
#define ITEM_H

class Item
{
public:
    Item();
};

#endif // ITEM_H
