#ifndef DISTRICT_H
#define DISTRICT_H

class District
{
public:
    District();
};

#endif // DISTRICT_H
