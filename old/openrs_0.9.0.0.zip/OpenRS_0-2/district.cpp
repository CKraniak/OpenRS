#include "district.h"

District::District()
{
}
