#include "component.h"

Component::Component()
{

}
