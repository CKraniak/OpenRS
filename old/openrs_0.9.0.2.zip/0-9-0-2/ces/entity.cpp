#include "entity.h"

Entity::Entity()
{

}
